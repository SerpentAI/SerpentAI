CONFIG = dict((('extra_compile_args', ['-UNDEBUG', '-w', '/FIPython.h']), ('extra_sources', ['lib/mdb.c', 'lib/midl.c']), ('extra_library_dirs', []), ('extra_include_dirs', ['lib/py-lmdb', 'lib', 'lib\\win32']), ('libraries', ['Advapi32'])))

